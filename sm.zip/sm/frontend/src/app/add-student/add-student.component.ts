import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms"
import { MasterService } from '../service/master.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.scss']
})
export class AddStudentComponent implements OnInit {

  // studentForm:any= FormGroup
  errormessage = '';
  errorclass = '';
  successMessage = '';
  successClass = '';
  saveresponse: any;
  editdata: any;
  destdata:any;
  avatar:any;

  studentForm = new FormGroup({

    fname: new FormControl(),
    lname: new FormControl(),
    email: new FormControl(),
    mobile: new FormControl(),
    password: new FormControl(),
    roll: new FormControl(),
    registrationDate: new FormControl(),
    department: new FormControl(),
    gender: new FormControl(),
    parentName: new FormControl(),
    bloodGroup: new FormControl(),
    designation: new FormControl(),
    avatar: new FormControl()

  });

  constructor(private service:MasterService,private fb: FormBuilder) {

    // this.studentForm =this.fb.group({
    //   fname:["",],
    //   lname:["",],
    //   username:["",],
    //   email:[""],
    //   mobile:["",],
    //   password:[""],
    //   roll:[""],
    //   registrationDate:[""],
    //   department:[""],
    //   gender:[""],
    //   parentName:[""],
    //   parentMobileNumber:[""],
    //   birthDate:[""],
    //   permanentAddress:[""],
    //   bloodGroup:[""],
    //   avatar:[""],
    // })

  }

  ngOnInit(): void {
  }




  Clearform(){
    this.studentForm.setValue({
      fname: '',
      lname: '',
      username: '',
      email: '',
      mobile: '',
      password: '',
      roll: '',
      registrationDate: '',
      department: '',
      gender: '',
      parentName: '',
      parentMobileNumber: '',
      birthDate: '',
      permanentAddress: '',
      bloodGroup: '',
      avatar: ''
    })
  }
   formData = new FormData()

    handleAvatar(event:any){
      // this.formData
      // console.log(event.files[0]);

      if (event.target.files.length > 0) {
        const file = event.target.files[0];
        console.log(file);
        this.avatar = file;
      }

    }


  saveStudent(){
    const formdata = new FormData();

    formdata.append('file', this.avatar);
    if (this.studentForm.valid) {

      console.log(this.studentForm.getRawValue());

      this.service.SaveStudentData(this.studentForm.getRawValue()).subscribe(result => {
        this.saveresponse = result;

        if (this.saveresponse.result == 'pass') {

          this.successMessage = "Saved Sucessfully";
          this.successClass = "sucessmessage";

        } else {
          this.errormessage = "Failed to save";
          this.errorclass = "errormessage";
        }
      });

    } else {
      this.errormessage = "Please enter valid data";
      this.errorclass = "errormessage";
    }

  }


  get fname() {
    return this.studentForm.get("fname");
  }
  get lname() {
    return this.studentForm.get("lname");
  }
  get username() {
    return this.studentForm.get("username");
  }
  get email() {
    return this.studentForm.get("email");
  }



}
