import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {map, Observable, tap} from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class MasterService {
  private _refreshrequired: any;

  constructor(private http:HttpClient) { }
  apiUrl ="http://localhost:5000";
  studentList:any;
  getUserData():Observable<any>{
    return this.http.get<any>(`${this.apiUrl}/users`).pipe(map((res:any) => {
      return res;
    }));
  }

  SaveStudentData(inputData: any){
    return this.http.post<any>(`${this.apiUrl}/users`, inputData).pipe(
      tap(() => {
        this._refreshrequired.next()
      })
    )
  }
}
