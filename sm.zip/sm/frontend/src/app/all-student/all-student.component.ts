import { Component, OnInit } from '@angular/core';
import { MasterService } from '../service/master.service';

@Component({
  selector: 'app-all-student',
  templateUrl: './all-student.component.html',
  styleUrls: ['./all-student.component.scss']
})

export class AllStudentComponent implements OnInit {
  allStudent:any[] = [];
  constructor(private service:MasterService) {

    this.service.getUserData().subscribe(result => {
      this.allStudent = result.users;
    })

  }

  ngOnInit(): void {
  }
}
