
const mongoose = require("mongoose");

const peopleSchema = mongoose.Schema(
    {
        fname: {
            type: String,
            trim: true,
        },
        lname: {
            type: String,
            trim: true,
        },
        username: {
            type: String,
            required: true,
            trim: true,
        },
        email: {
            type: String,
            required: true,
            trim: true,
            lowercase: true,
        },
        mobile: {
            type: String,
            required: true,
        },
        password: {
            type: String,
            required: true,
        },
        roll: {
            type: String,
        },
        registrationDate: {
            type: String,
        },
        department: {
            type: String,
        },
        gendar: {
            type: String,
        },
        parentName: {
            type: String,
        },
        parentMobileNumber: {
            type: String,
        },
        birthDate: {
            type: String,
        },
        permanentAddress: {
            type: String,
        },
        avatar: {
            type: String,
        }
    },
    {
        timeStamps: true,
    }
)

const People = mongoose.model("People", peopleSchema);
module.exports = People;