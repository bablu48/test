const express = require("express");
const { addUser, getUsers } = require("../controller/usersController");
const avatarUpload = require("../middleware/users/avatarUpload");

const router = express.Router();

// add user
router.post("/", avatarUpload, addUser);

// get user
router.get("/", getUsers)

module.exports = router;