
const express = require('express');
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const cors = require("cors")


const app = express();
dotenv.config();


const usersRouter = require("./routers/usersRouter")


// database connection
mongoose.connect(process.env.MONGO_CONNECTION_STRING, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
    console.log("Database Connection Successfull")
})
.catch((err) => {
    console.log("Database connection Failed!!!", err)
})
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: true}));


// routing setup
app.use("/users", usersRouter)



app.listen(process.env.PORT, () => {
    console.log(`app listening to port ${process.env.PORT}`);
})